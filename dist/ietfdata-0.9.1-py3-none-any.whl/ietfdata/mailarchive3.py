# Copyright (C) 2020-2026 University of Glasgow
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from __future__    import annotations

import pandas as pd
import os
import logging
import re
import sqlite3
import sys
import time

from datetime                 import date, datetime, timezone, UTC
from email                    import policy, message_from_bytes
from email.headerregistry     import Address
from email.message            import Message
from typing                   import Dict, Iterator, List, Optional, Tuple, Union, Any

from ietfdata.ma_backend      import MailArchiveBackend
from ietfdata.ma_backend_ietf import MailArchiveBackendIETF
from ietfdata.ma_backend_w3c  import MailArchiveBackendW3C
from ietfdata.ma_parsing      import EmailPolicyCustom, parse_message

# =================================================================================================

class Envelope:
    """
    An Envelope holds a single email message.
    """
    _archive       : MailArchive
    _prefix        : str
    _message_num   : int
    _mailing_list  : str
    _uidvalidity   : int
    _uid           : int
    _message       : bytes

    def __init__(self, mail_archive: MailArchive, message_num : int) -> None:
        self._archive = mail_archive
        self._prefix  = mail_archive._prefix
        self._message_num = message_num

        dbc = self._archive._db.cursor()
        sql = f"SELECT mailing_list, uidvalidity, uid, message FROM {self._prefix}_ma_msg WHERE message_num = ?;"
        res = dbc.execute(sql, (message_num, )).fetchone()
        self._mailing_list  = res[0]
        self._uidvalidity   = res[1]
        self._uid           = res[2]
        self._message       = res[3]


    def mailing_list(self) -> MailingList:
        """
        Retrieve the mailing list that holds this envelope.
        """
        return self._archive.mailing_list(self._mailing_list)


    def uidvalidity(self) -> int:
        """
        Retrieve the uidvalidity of the envelope.

        The uidvalidity is not supposed to change, but mailboxes occasionally
        get rebuilt. When this happens, the uidvalidity will change.
        """
        return self._uidvalidity


    def uid(self) -> int:
        """
        Retrieve the uid of the envelope.

        The combination of the mailing list, uidvalidity, and uid uniquely
        identifies an envelope on the server.
        """
        return self._uid


    def message_id(self) -> str:
        """
        Retrieve the "Message-ID" from the envelope.

        A Message-ID is chosen by the sender of a message and is intended to
        be globally unique identifier for that message. There can be several
        envelopes with the same Message-ID on a server if the message was
        copied to several different mailing lists.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT message_id FROM {self._prefix}_ma_hdr WHERE message_num = ?;"
        res = dbc.execute(sql, (self._message_num, )).fetchone()
        return str(res[0])


    def from_(self) -> Optional[Address]:
        """
        Retrieve the parsed "From:" address from the envelope, or return `None`
        if the header is missing or cannot be parsed.

        This library uses a number of heuristics to correct malformed headers,
        so the value returned might differ from the uncorrected value returned
        by calling `header("from")`. 
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT from_name, from_addr FROM {self._prefix}_ma_hdr WHERE message_num = ?;"
        name, addr = dbc.execute(sql, (self._message_num, )).fetchone()

        # Check the name is valid:
        if name is None:
            name = ""

        # Check the addr is valid:
        if addr is None or addr == "":
            return None
        if addr.count("@") != 1:
            raise RuntimeError(f"Invalid From: addr in {self._message_num}: {addr}")

        return Address(display_name = name, addr_spec = addr)


    def to(self) -> List[Address]:
        """
        Retrieve the parsed "To:" address from the envelope.

        This library uses a number of heuristics to correct malformed headers,
        so the value returned might differ from the uncorrected value returned
        by calling `header("to")`.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT to_name, to_addr FROM {self._prefix}_ma_hdr_to WHERE message_num = ?;"
        res = []
        for name, addr in dbc.execute(sql, (self._message_num, )).fetchall():
            res.append(Address(display_name = name, addr_spec = addr))
        return res


    def cc(self) -> List[Address]:
        """
        Retrieve the parsed "Cc:" address from the envelope.

        This library uses a number of heuristics to correct malformed headers,
        so the value returned might differ from the uncorrected value returned
        by calling `header("cc")`.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT cc_name, cc_addr FROM {self._prefix}_ma_hdr_cc WHERE message_num = ?;"
        res = []
        for name, addr in dbc.execute(sql, (self._message_num, )).fetchall():
            res.append(Address(display_name = name, addr_spec = addr))
        return res


    def subject(self) -> str:
        """
        Retrieve the parsed "Subject:" header from the envelope.

        This library uses a number of heuristics to correct malformed headers,
        so the value returned might differ from the uncorrected value returned
        by calling `header("subject")`.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT subject FROM {self._prefix}_ma_hdr WHERE message_num = ?;"
        res = dbc.execute(sql, (self._message_num, )).fetchone()
        return str(res[0])


    def date(self) -> Optional[datetime]:
        """
        Retrieve the "Date:" header from the envelope, parsed into a `DateTime`
        object, or return `None` if the header is missing or cannot be parsed.

        This library uses a number of heuristics to correct malformed headers
        so the value returned by this method might differ from the uncorrected
        value returned by calling `header("date")`.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT date FROM {self._prefix}_ma_hdr WHERE message_num = ?;"
        res = dbc.execute(sql, (self._message_num, )).fetchone()
        if res[0] is not None:
            return datetime.fromisoformat(res[0]).astimezone(UTC)
        else:
            return None


    def header(self, header_name:str) -> List[str]:
        """
        Retrieve unparsed headers from the envelope.

        You SHOULD use the `from_()`, `to()`, `cc()`, `subject()`, `date()`,
        and `message_id()` methods instead of calling this method to retrieve
        those header fields. This library heuristics to correct for malformed
        headers that are applied when calling the dedicated accessor methods
        but not when calling this method.

        Some headers, e.g., "Received:" are expected to occur multiple times
        within an envelope and will return a list containing multiple items.

        Other headers, e.g., "From:", are only supposed to occur once in each
        envelope. In these cases, this method should return a list containing a
        single value. Note, however, that the mail archive might contain some
        malformed envelope with unexpected duplicate headers. For example,
        there are some envelope with two addresses in the "From:" line in the
        IETF archive.
        """
        msg = message_from_bytes(self._message, policy=policy.default)
        try:
            res = msg.get_all(header_name)
            if res is None:
                return []
            else:
                return res
        except:
            self._archive._log.warning(f"mailarchive3:envelope:header: cannot parse \"{header_name}\" header")
            return []


    def contents(self) -> Message:
        """
        Retrieve the message contained within the envelope.
        """
        return message_from_bytes(self._message, policy=policy.default)


    def in_reply_to(self) -> List[Envelope]:
        """
        Retrieve the envelopes containing the messages that this is in reply to.

        Each message can only be in reply to a single other message, but there
        may be multiple copies of that message in the archive if it was sent to
        multiple lists, each of which may itself have different replies. This
        method returns all such copies.

        If this is the first message in a thread, then an empty list is returned.
        """
        in_reply_to = self.header("in-reply-to")
        references  = self.header("references")
        if in_reply_to is not None and len(in_reply_to) > 0:
            parent = in_reply_to[0]
        elif references is not None and len(references) > 0:
            parent = references[0].split(" ")[-1]
        else:
            return []
        return self._archive.message(parent)


    def replies(self) -> List[Envelope]:
        """
        Retrieve the envelopes containing the messages sent in reply to this.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT message_num FROM {self._prefix}_ma_hdr WHERE in_reply_to = ?;"
        replies = []
        for message_num in dbc.execute(sql, (self.message_id(), )).fetchall():
            replies.append(Envelope(self._archive, message_num[0]))
        return replies


    def add_metadata(self, project:str, key:str, value:str) -> None:
        """
        Add metadata relating to the message in this envelope.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata should be scored
        - `value`   -- the value of the metadata to store

        The `project` is intended to allow different users to store metadata
        in a shared mail archive database. For example, a group project that
        works with the mail archive might tag message envelopes with agreed-
        upon metadata using the project's name in the `project` field, while
        exploratory work from individual members of the project might use
        their username as the basis for the `project` (e.g., "alice_test4").
        """
        dbc = self._archive._db.cursor()
        sql = f"""INSERT OR REPLACE INTO {self._prefix}_ma_msg_metadata
                 VALUES ((SELECT id FROM {self._prefix}_ma_msg_metadata WHERE message_num = ? and project = ? AND key_ = ?), ?, ?, ?, ?)"""
        dbc.execute(sql, (self._message_num, project, key, self._message_num, project, key, value))
        self._archive._db.commit()


    def get_metadata(self, project:str, key:str) -> Optional[str]:
        """
        Get metadata relating to the message in this envelope.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata was scored
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT value FROM {self._prefix}_ma_msg_metadata WHERE message_num = ? AND project = ? AND key_ = ?;"
        res = dbc.execute(sql, (self._message_num, project, key)).fetchone()
        if res is None:
            return None
        else:
            return str(res[0])


    def clear_metadata(self, project:str, key:Optional[str] = None) -> None:
        """
        Remove metadata relating to the message in this envelope.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata was scored

        If the `key` is specified then only the single metadata value
        identified by the `project` and `key` is removed. If the `key`
        is not specified, then all metadata relating to `project` is
        removed from this envelope.
        """
        dbc = self._archive._db.cursor()
        if key is None:
            sql = f"DELETE FROM {self._prefix}_ma_msg_metadata WHERE message_num = ? AND project = ?;"
            dbc.execute(sql, (self._message_num, project))
        else:
            sql = f"DELETE FROM {self._prefix}_ma_msg_metadata WHERE message_num = ? AND project = ? AND key_ = ?;"
            dbc.execute(sql, (self._message_num, project, key))
        self._archive._db.commit()


# =================================================================================================


class MailingList:
    """
    A class representing a mailing list.
    """

    _archive : MailArchive
    _prefix  : str
    _name    : str

    def __init__(self, mail_archive: MailArchive, list_name: str):
        self._archive = mail_archive
        self._prefix  = mail_archive._prefix
        self._name    = list_name


    def name(self) -> str:
        return self._name


    def uidvalidity(self) -> Optional[int]:
        dbc = self._archive._db.cursor()
        sql = f"SELECT uidvalidity FROM {self._prefix}_ma_lists WHERE name = (?);"
        res = dbc.execute(sql, (self._name, )).fetchone()[0]
        if res is None:
            return None
        else:
            return int(res)


    def num_messages(self) -> int:
        dbc = self._archive._db.cursor()
        sql = f"SELECT COUNT(*) FROM {self._prefix}_ma_msg WHERE mailing_list = (?);"
        return int(dbc.execute(sql, (self._name, )).fetchone()[0])


    def message_uids(self) -> Iterator[int]:
        dbc = self._archive._db.cursor()
        sql = f"SELECT uid FROM {self._prefix}_ma_msg WHERE mailing_list = ? and uidvalidity = ?;"
        for uid in map(lambda x : x[0], dbc.execute(sql, (self.name(), self.uidvalidity()))):
            yield uid


    def message(self, uid: int) -> Optional[Envelope]:
        """
        Return the Envelope containing the Message identified by the
        specified uid within this mailing list.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT message_num FROM {self._prefix}_ma_msg WHERE mailing_list = ? and uidvalidity = ? and uid = ?;"
        arg = (self._name, self.uidvalidity(), uid)
        res = dbc.execute(sql, arg).fetchone()
        if res is None:
            return None
        else:
            return Envelope(self._archive, int(res[0]))


    def messages(self) -> Iterator[Envelope]:
        """
        Return the envelopes containing the specified messages from this mailing list.
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT message_num FROM {self._prefix}_ma_msg WHERE mailing_list = ? AND uidvalidity = ?;"
        arg = (self.name(), self.uidvalidity())
        for res in map(lambda x : x[0], dbc.execute(sql, arg).fetchall()):
            assert res is not None
            yield Envelope(self._archive, res)


    def messages_as_dataframe(self) -> pd.DataFrame:
        """
        Return a dataframe containing information about the specified messages from
        this mailing list.
        """
        messages_as_dict = []
        for message in self.messages():
            mdict = {"Message-ID"  : message.message_id(),
                     "From"        : message.from_(),
                     "To"          : message.to(),
                     "Cc"          : message.cc(),
                     "Subject"     : message.subject(),
                     "Date"        : message.date(),
                     "In-Reply-To" : message.header("in-reply-to") if message.header("in-reply-to") != [] else None,
                     "References"  : message.header("references"),
                    }
            messages_as_dict.append(mdict)
        df = pd.DataFrame(data=messages_as_dict)
        df.set_index("Message-ID", inplace=True)
        return df


    def update(self, verbose=True) -> List[int]:
        """
        Update the local copy of this mailing list from the server.

        This MUST be called at least once for each mailing list, else no
        messages will be retrieved from the server. That initial update
        may well be slow, since it downloads the entire set of messages
        from the list. Subsequent calls to `update()` only fetch the new
        messages and so are much faster.
        """
        if verbose:
            print(f"Downloading {self._name}")

        self._archive._backend.open_mailbox(self._name)

        # Retrieve and save uidvalidity:
        uidvalidity = self._archive._backend.validity()
        dbc = self._archive._db.cursor()
        sql = f"INSERT OR REPLACE INTO {self._prefix}_ma_lists (name, uidvalidity) VALUES (?, ?);"
        dbc.execute(sql, (self.name(), uidvalidity))
        self._archive._db.commit()

        # FIXME: remove messages from database where uidvalidity doesn't match

        # Retrieve messages on server but not in database:
        sql = f"SELECT uid FROM {self._prefix}_ma_msg WHERE mailing_list = ? and uidvalidity = ?;"
        msg_local  = set(map(lambda x : x[0], dbc.execute(sql, (self.name(), uidvalidity))))
        msg_remote = set(self._archive._backend.message_ids())
        msg_to_fetch = list(msg_remote - msg_local)

        self._archive._log.info(f"mailarchive3:update: {len(msg_local)} messages in archive")
        self._archive._log.info(f"mailarchive3:update: {len(msg_remote)} messages on server")
        self._archive._log.info(f"mailarchive3:update: {len(msg_to_fetch)} messages to fetch")

        unknown_msgs = list(msg_local - msg_remote)
        if len(unknown_msgs) > 0:
            self._archive._log.warning(f"mailarchive3:update: {len(unknown_msgs)} unknown local messages ")

        for i in range(0, len(msg_to_fetch), 16):
            uid_slice = msg_to_fetch[slice(i, i+16, 1)]
            for uid, msg in self._archive._backend.fetch(uid_slice):
                self._archive._log.info(f"mailarchive3:update: {self._name}/{uid} (uidvalidity={uidvalidity})")
                cur = self._archive._db.cursor()
                sql = f"INSERT INTO {self._prefix}_ma_msg VALUES (?, ?, ?, ?, ?) RETURNING message_num"
                num = cur.execute(sql, (None, self._name, uidvalidity, uid, msg)).fetchone()[0]
            self._archive._db.commit()

        self._archive._backend.close_mailbox()

        if len(msg_to_fetch) > 0:
            self.reindex(verbose)

        return msg_to_fetch



    def reindex(self, verbose=True) -> None:
        """
        Rebuild the database tables indexing this mailing list.

        The mailing list archives may contain a number of messages with
        malformed or corrupt "Date:", "From:", "To:", and "Cc:" headers.
        This library attempts to correct these headers when indexing the
        retrieved messages. This method refreshes the index for messages
        that have been previously retrieved.

        It is worthwhile to call this method after updating to a new
        version of this library, since the newer version might include
        improved heuristics for detecting and correcting problems with
        the mail archive.

        This function operates on the previously retrieved mail archive
        only, and does not contact the mail server.
        """
        if verbose:
            print(f"Re-indexing {self._name}")

        uidvalidity = self.uidvalidity()
        assert uidvalidity is not None

        dbc = self._archive._db.cursor()
        sql = f"SELECT message_num, uid, message FROM {self._prefix}_ma_msg WHERE mailing_list = ? and uidvalidity = ?;"
        for message_num, uid, message in dbc.execute(sql, (self.name(), uidvalidity)).fetchall():
            self._archive._log.debug(f"mailarchive3:reindex: {self._name}/{uid}")

            parsed_msg = parse_message(uidvalidity, uid, message)
            val = (message_num,
                   message_num,
                   parsed_msg["from_name"],
                   parsed_msg["from_addr"],
                   parsed_msg["subject"],
                   parsed_msg["date"],
                   parsed_msg["message_id"],
                   parsed_msg["in_reply_to"])
            sql = f"""INSERT OR REPLACE INTO {self._prefix}_ma_hdr
                     VALUES ((SELECT id FROM {self._prefix}_ma_hdr WHERE message_num = ?), ?, ?, ?, ?, ?, ?, ?)"""
            dbc.execute(sql, val)

            max_index = 0
            for index, name, addr in parsed_msg["to"]:
                if index > max_index:
                    max_index = index
                sql = f"""INSERT OR REPLACE INTO {self._prefix}_ma_hdr_to
                         VALUES ((SELECT id FROM {self._prefix}_ma_hdr_to WHERE message_num = ? AND to_index = ?), ?, ?, ?, ?)"""
                dbc.execute(sql, (message_num, index, message_num, index, name, addr))
            sql = f"DELETE FROM {self._prefix}_ma_hdr_to WHERE message_num = ? AND to_index > ?;"
            dbc.execute(sql, (message_num, max_index))

            max_index = 0
            for index, name, addr in parsed_msg["cc"]:
                if index > max_index:
                    max_index = index
                sql = f"""INSERT OR REPLACE INTO {self._prefix}_ma_hdr_cc
                         VALUES ((SELECT id FROM {self._prefix}_ma_hdr_cc WHERE message_num = ? AND cc_index = ?), ?, ?, ?, ?)"""
                dbc.execute(sql, (message_num, index, message_num, index, name, addr))
            sql = f"DELETE FROM {self._prefix}_ma_hdr_cc WHERE message_num = ? AND cc_index > ?;"
            dbc.execute(sql, (message_num, max_index))

            self._archive._db.commit()


    def threads(self, this_list_only=False) -> Dict[str, List[Envelope]]:
        """
        Returns a dictionary of threads in this mailing list.

        The dictionary returned maps message-id values of the first messages in
        each thread to lists of the Envelope objects containing that message.

        Threads frequently start on one mailing list and have later messages
        sent to a different mailing list. If you have a complete copy of the
        mail archive (i.e., if you previously called `MailArchive::update()`),
        then this function will track threads across lists to find the first
        message in each (unless `this_list_only` is set to True).

        The first message in a thread can be copied to several mailing lists.
        If this happens, the message-id for the thread will map to a list of
        Envelope objects, each representing a copy of the message sent to a
        different mailing list.
        If the first message in the thread was only sent to a single mailing
        list, then the message-id for the thread will map onto a list with a
        single Envelope.
        """
        threads = {}
        seen    = {} # type: Dict[str,Envelope]
        for msg in self.messages():
            if len(msg.header("message-id")) > 0:
                msg_id = msg.message_id()
                seen[msg_id] = msg

                self._archive._log.debug(f"{msg.uid():5} {msg.message_id()} {msg.subject()}")

                parents = msg.in_reply_to()
                if len(parents) == 0:
                    # This is the first message in the thread
                    if msg.message_id() not in threads:
                        threads[msg.message_id()] = self._archive.message(msg.message_id())
                    self._archive._log.debug("      First in thread")
                elif parents[0].message_id() in seen:
                    # This is part of a thread we've already seen
                    self._archive._log.debug(f"      {parents[0].message_id()} {parents[0].subject()}")
                    self._archive._log.debug(f"      Continues known thread")
                else:
                    # This is either a new thread that has been copied to this list
                    # where the earlier messages in the thread are on another list,
                    # or this message is part of an existing thread but has arrived
                    # before its parent.
                    curr = []
                    curr.append(msg)
                    while True:
                        parents = curr[0].in_reply_to()
    
                        parent_in_this_list = False
                        for p in parents:
                            if p.mailing_list() == self.name():
                                parent_in_this_list = True
                        if not parent_in_this_list and this_list_only:
                            self._archive._log.debug(f"      {parents[0].message_id()} {parents[0].subject()}")
                            self._archive._log.debug(f"      Not in this list")
                            if curr[0].message_id() not in threads:
                                threads[curr[0].message_id()] = curr
                            break
    
                        if len(parents) == 0:
                            self._archive._log.debug("      First in thread")
                            if curr[0].message_id() not in threads:
                                threads[curr[0].message_id()] = curr
                            break
                        curr = parents
                        self._archive._log.debug(f"      {curr[0].message_id()} {curr[0].subject()}")
        return threads


    def add_metadata(self, project:str, key:str, value: str) -> None:
        """
        Add metadata relating to the list.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata should be scored
        - `value`   -- the value of the metadata to store

        The `project` is intended to allow different users to store metadata
        in a shared mail archive database. For example, a group project that
        works with the mail archive might tag message envelopes with agreed-
        upon metadata using the project's name in the `project` field, while
        exploratory work from individual members of the project might use
        their username as the basis for the `project` (e.g., "alice_test4").
        """
        dbc = self._archive._db.cursor()
        sql = f"""INSERT OR REPLACE INTO {self._prefix}_ma_list_metadata
                 VALUES ((SELECT id FROM {self._prefix}_ma_list_metadata WHERE mailing_list = ? and project = ? AND key_ = ?), ?, ?, ?, ?)"""
        dbc.execute(sql, (self._name, project, key, self._name, project, key, value))
        self._archive._db.commit()


    def get_metadata(self, project:str, key:str) -> Optional[str]:
        """
        Get metadata relating to the list.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata was scored
        """
        dbc = self._archive._db.cursor()
        sql = f"SELECT value FROM {self._prefix}_ma_list_metadata WHERE mailing_list = ? AND project = ? AND key_ = ?;"
        res = dbc.execute(sql, (self._name, project, key)).fetchone()
        if res is None:
            return None
        else:
            return str(res[0])


    def clear_metadata(self, project:str, key:Optional[str] = None) -> None:
        """
        Remove metadata relating to the list.

        Parameters:
        - `project` -- the project or user to which this metadata relates
        - `key`     -- the key under which the metadata was scored

        If the `key` is specified then only the single metadata value
        identified by the `project` and `key` is removed. If the `key`
        is not specified, then all metadata relating to `project` is
        removed from this envelope.
        """
        dbc = self._archive._db.cursor()
        if key is None:
            sql = f"DELETE FROM {self._prefix}_ma_list_metadata WHERE mailing_list = ? AND project = ?;"
            dbc.execute(sql, (self._name, project))
        else:
            sql = f"DELETE FROM {self._prefix}_ma_list_metadata WHERE mailing_list = ? AND project = ? AND key_ = ?;"
            dbc.execute(sql, (self._name, project, key))
        self._archive._db.commit()


# =================================================================================================

class MailArchive:
    """
    A class representing an email archive.
    """
    _log     : logging.Logger
    _backend : MailArchiveBackend

    # Differs from mailarchiv2
    def __init__(self,
                 sqlite_file : str = "ietfdata.sqlite",
                 backend     : MailArchiveBackend = MailArchiveBackendIETF()) -> None:
        """
        Initialise the MailArchive.

        If it doesn't exist, an sqlite3 database, specified by the
        `sqlite_file` argument, is created to hold a local copy of the mail
        archive. The database will initially be empty and must be populated
        before it can be used. There are two ways to populate the database:

        1. Call the `update()` method to populate the database with a complete
           copy of the mail archive. As of January 2025 the complete IETF mail
           archive is around 35 gigabytes in size.

        2. Call the `update_mailing_list_names()` method to add the mailing
           list names to the database. Then, use the `mailing_list_names()`
           method to query what lists exist and `update_mailing_list()` to
           populate the database with only the lists of interest.

        In normal operation, calling `update()` to fetch the complete mail
        archive is the right thing to do.
        """
        logging.basicConfig(level=os.environ.get("IETFDATA_LOGLEVEL", "INFO"))

        self._backend = backend
        self._log = logging.getLogger("ietfdata")
        assert sqlite3.threadsafety == 3
        self._db  = sqlite3.connect(sqlite_file, check_same_thread=False)
        self._prefix = backend.db_prefix()
        self._db.execute('PRAGMA synchronous = OFF;')
        self._db.execute('PRAGMA foreign_keys = ON;')
        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_lists (
                                name        TEXT NOT NULL PRIMARY KEY,
                                uidvalidity INTEGER
                            );""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_lists
                             ON {self._prefix}_ma_lists (name);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_list_metadata (
                                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                                mailing_list TEXT NOT NULL,
                                project      TEXT,
                                key_         TEXT,
                                value        TEXT);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_list_metadata
                             ON {self._prefix}_ma_list_metadata (mailing_list, project, key_);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_msg (
                                message_num   INTEGER PRIMARY KEY AUTOINCREMENT,
                                mailing_list  TEXT NOT NULL,
                                uidvalidity   INTEGER NOT NULL,
                                uid           INTEGER NOT NULL,
                                message       BLOB
                            );""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_msg
                             ON {self._prefix}_ma_msg (message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_msg_uidvalidity_uid
                             ON {self._prefix}_ma_msg (mailing_list, uidvalidity, uid);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_hdr (
                                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                                message_num  INTEGER,
                                from_name    TEXT,
                                from_addr    TEXT,
                                subject      TEXT,
                                date         TEXT,
                                message_id   TEXT,
                                in_reply_to  TEXT,
                                FOREIGN KEY (message_num)  REFERENCES {self._prefix}_ma_msg (message_num)
                            );""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr
                             ON {self._prefix}_ma_hdr (message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_messageid
                             ON {self._prefix}_ma_hdr (message_id, message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_in_reply
                             ON {self._prefix}_ma_hdr (in_reply_to, message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_from_addr_date
                             ON {self._prefix}_ma_hdr (message_num, from_addr, date);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_from_name_date
                             ON {self._prefix}_ma_hdr (message_num, from_name, date);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_date_subject
                             ON {self._prefix}_ma_hdr (message_num, date, subject);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_hdr_to (
                                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                                message_num INTEGER,
                                to_index    INTEGER,
                                to_name     TEXT,
                                to_addr     TEXT,
                                FOREIGN KEY (message_num) REFERENCES {self._prefix}_ma_msg (message_num)
                            );""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_to
                             ON {self._prefix}_ma_hdr_to (message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_to_to_index
                             ON {self._prefix}_ma_hdr_to (message_num, to_index);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_hdr_cc (
                                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                                message_num INTEGER,
                                cc_index    INTEGER,
                                cc_name     TEXT,
                                cc_addr     TEXT,
                                FOREIGN KEY (message_num) REFERENCES {self._prefix}_ma_msg (message_num)
                            );""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_cc
                             ON {self._prefix}_ma_hdr_cc (message_num);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_hdr_cc_cc_index
                             ON {self._prefix}_ma_hdr_cc (message_num, cc_index);""")

        self._db.execute(f"""CREATE TABLE IF NOT EXISTS {self._prefix}_ma_msg_metadata (
                                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                                message_num INTEGER,
                                project     TEXT,
                                key_        TEXT,
                                value       TEXT);""")
        self._db.execute(f"""CREATE INDEX IF NOT EXISTS index_{self._prefix}_ma_msg_metadata
                             ON {self._prefix}_ma_msg_metadata (message_num, project, key_);""")

        self._db.commit()


    def update_mailing_list_names(self) -> None:
        """
        Contact the mail server and update the local copy of the list of
        mailing lists that are available.

        In normal operation you do not need to call this method. It should only
        be used if you plan to download only a subset of the mailing lists, in
        which case you should call this method, then `mailing_list_names()` to
        query what lists exist, then `update_mailing_list()` to populate the
        local database with the messages from the lists of interest.
        """
        dbc = self._db.cursor()
        for name in self._backend.mailboxes():
            dbc.execute(f"INSERT OR IGNORE INTO {self._prefix}_ma_lists (name) VALUES (?)", (name,))
        self._db.commit()


    def update_mailing_list(self, mailing_list_name: str) -> None:
        """
        Contact the mail serer to update the local copy of the specified
        mailing list.

        In normal operation you do not need to call this method. It's only used
        when working with a partial copy of the mail archive, as discussed in
        the documentation for `update_mailing_list_names()`.
        """
        ml = self.mailing_list(mailing_list_name)
        ml.update()


    def update(self, verbose=True) -> None:
        """
        Contact the mail server to update the local copy of the mailing list
        archive.

        This method should be called when working with a complete copy of
        the mail archive to synchronise the local copy of the archive with
        the mail server.

        WARNING: The first time this method is called, it will download the
        entire mail archive. This will take several hours and download tens
        of gigabytes of data. Subsequent calls will fetch only new data and
        so will be much faster.
        """
        self.update_mailing_list_names()
        for ml_name in self.mailing_list_names():
            ml = self.mailing_list(ml_name)
            ml.update(verbose)


    def reindex(self, verbose=True) -> None:
        """
        Rebuild the header indexes.

        This rebuilds the index of message headers baed on the downloaded
        messages. It's recommended to run this after updating this library
        since improvements to the heading parsing code may result in more
        accurate indexes.

        Calling `update()` or `update_mailing_list()` will automatically
        reindex any mailing lists that are updated, so there is no need
        to call this method after those operations.

        This nmethod operates locally based on the previously downloaded
        messages.
        """
        for ml_name in self.mailing_list_names():
            ml = self.mailing_list(ml_name)
            ml.reindex(verbose)


    def mailing_list_names(self) -> Iterator[str]:
        """
        Yield the names of the mailing lists that exist in the mail archive.
        """
        dbc = self._db.cursor()
        for name in dbc.execute(f"SELECT name FROM {self._prefix}_ma_lists;", ()):
            yield name[0]


    def mailing_list(self, mailing_list_name: str) -> MailingList:
        """
        Return an object representing the given mailing list.
        """
        return MailingList(self, mailing_list_name)


    def message(self, message_id:str) -> List[Envelope]:
        """
        Return the envelopes for all messages with the specified `message_id`.

        There can be several copies of a message with a particular `message_id`
        in the archive if the message was sent to multiple lists. This method
        returns all the copies since each might have a different set of replies.
        In the IETF mail archive, for example, the message with `message_id`
        "<396c8d37-f979-73fe-34fa-475a038b94f8@alum.mit.edu>" appears in the
        archives of the "art", "last-call", and "tsvwg" lists.
        """
        dbc = self._db.cursor()
        sql = f"SELECT message_num FROM {self._prefix}_ma_hdr WHERE message_id = ?;"
        msgs = []
        for msg_num in map(lambda x : x[0], dbc.execute(sql, (message_id, )).fetchall()): 
            msgs.append(Envelope(self, msg_num))
        return msgs


    def messages(self,
                 mailing_list_name : Optional[str] = None, # Exact match
                 sent_after        : str = "1970-01-01T00:00:00",
                 sent_before       : str = "2038-01-19T03:14:07",
                 from_name         : Optional[str] = None, # Substring match
                 from_addr         : Optional[str] = None,
                 to_addr           : Optional[str] = None,
                 cc_addr           : Optional[str] = None,
                 subject           : Optional[str] = None, # Substring match
                 message_id        : Optional[str] = None,
                 in_reply_to       : Optional[str] = None,
                ) -> Iterator[Envelope]:
        """
        Search the local copy of the mail archive, returning the envelopes of
        the messages that match all of the specified criteria.
        """
        dbc = self._db.cursor()
        query = f"""SELECT DISTINCT {self._prefix}_ma_msg.message_num
                   FROM {self._prefix}_ma_msg
                   LEFT JOIN {self._prefix}_ma_hdr    ON {self._prefix}_ma_msg.message_num = {self._prefix}_ma_hdr.message_num
                   LEFT JOIN {self._prefix}_ma_hdr_to ON {self._prefix}_ma_msg.message_num = {self._prefix}_ma_hdr_to.message_num
                   LEFT JOIN {self._prefix}_ma_hdr_cc ON {self._prefix}_ma_msg.message_num = {self._prefix}_ma_hdr_cc.message_num
                   WHERE """
        sql = []
        arg = []
        if mailing_list_name is not None:
            sql.append("mailing_list == ?")
            arg.append(mailing_list_name)

        sql.append("date >= ?")
        arg.append(sent_after)
        sql.append("date < ?")
        arg.append(sent_before)

        if from_name is not None:
            sql.append("from_name LIKE ?")
            arg.append(from_name)
        if from_addr is not None:
            sql.append("from_addr == ?")
            arg.append(from_addr)
        if to_addr is not None:
            sql.append("to_addr == ?")
            arg.append(to_addr)
        if cc_addr is not None:
            sql.append("cc_addr == ?")
            arg.append(cc_addr)
        if subject is not None:
            sql.append("subject LIKE ?")
            arg.append(f'%{subject}%')
        if message_id is not None:
            sql.append("message_id == ?")
            arg.append(message_id)
        if in_reply_to is not None:
            sql.append("in_reply_to == ?")
            arg.append(in_reply_to)

        query += " AND ".join(sql)
        query += ";"
        qplan  = dbc.execute("EXPLAIN QUERY PLAN " + query, arg).fetchone()
        self._log.debug(query)
        self._log.debug(qplan)
        for msg_num in map(lambda x : x[0], dbc.execute(query, arg).fetchall()): 
            yield Envelope(self, msg_num)


    def clear_metadata(self, project: str):
        """
        Remove metadata relating to the project from all mailing lists
        and message envelopes.

        WARNING: This is a destructive operation that should not normally
        be needed. Use with care.
        """
        for ml_name in self.mailing_list_names():
            ml = self.mailing_list(ml_name)
            ml.clear_metadata(project)


# =================================================================================================
# vim: set tw=0 ai:
